package in.vidyutsuraksha.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.Text as MaterialText
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler



// App-wide language selection. The Language tab changes all mapped interface and learning text.
private var appHindi by mutableStateOf(false)
private val hindiText = mapOf(
    "Electrical safety learning" to "विद्युत सुरक्षा शिक्षा", "Home" to "होम", "Learn" to "सीखें", "Quiz" to "प्रश्नोत्तरी", "Check" to "जाँच", "Progress" to "प्रगति", "Language" to "भाषा", "Safety Regulations" to "सुरक्षा विनियम", "Open CEA Safety Regulations, 2023" to "CEA सुरक्षा विनियम, 2023 खोलें", "Official Central Electricity Authority website" to "केंद्रीय विद्युत प्राधिकरण की आधिकारिक वेबसाइट", "Open official regulations page" to "आधिकारिक विनियम पृष्ठ खोलें", "Regulations open in your browser." to "विनियम आपके ब्राउज़र में खुलेंगे।",
    "LEARN SAFE. STAY SAFE." to "सुरक्षित सीखें। सुरक्षित रहें।", "Electrical safety starts with you." to "विद्युत सुरक्षा की शुरुआत आपसे होती है।", "Short lessons, practical checks and quick quizzes." to "छोटे पाठ, व्यावहारिक जाँच और त्वरित प्रश्नोत्तरी।",
    "Lessons" to "पाठ", "Quiz points" to "प्रश्नोत्तरी अंक", "Checks" to "जाँच", "Start learning" to "सीखना शुरू करें", "Safety lessons" to "सुरक्षा पाठ", "Six bite-sized topics" to "छह छोटे विषय", "Quick quiz" to "त्वरित प्रश्नोत्तरी", "Test your knowledge" to "अपना ज्ञान परखें", "Home safety check" to "घर की सुरक्षा जाँच", "Check common household hazards" to "घर के सामान्य खतरों की जाँच करें", "Emergency guide" to "आपातकालीन मार्गदर्शिका", "Shock, fire and fallen wires" to "बिजली का झटका, आग और गिरे तार",
    "Never touch a person who may still be in contact with electricity. Isolate power only if safe, keep away and call emergency services." to "जिस व्यक्ति का बिजली से संपर्क हो सकता है, उसे न छुएँ। सुरक्षित होने पर ही बिजली बंद करें, दूर रहें और आपातकालीन सेवा को बुलाएँ।",
    "Learning modules" to "सीखने के मॉड्यूल", "Choose a topic to study." to "अध्ययन के लिए विषय चुनें।", "Plugs, sockets & appliances" to "प्लग, सॉकेट और उपकरण", "Use electricity without overloading or damaging equipment." to "उपकरणों पर अधिक भार डाले या उन्हें नुकसान पहुँचाए बिना बिजली का उपयोग करें।", "Earthing & protective devices" to "अर्थिंग और सुरक्षा उपकरण", "Understand earthing, MCBs and RCCBs/RCDs." to "अर्थिंग, MCB और RCCB/RCD को समझें।", "Safe wiring at home" to "घर में सुरक्षित वायरिंग", "Recognise warning signs and arrange safe repairs." to "चेतावनी संकेत पहचानें और सुरक्षित मरम्मत करवाएँ।", "Overhead lines & outdoor safety" to "ओवरहेड लाइन और बाहरी सुरक्षा", "Stay away from overhead lines and fallen conductors." to "ओवरहेड लाइनों और गिरे तारों से दूर रहें।", "Workplace & electrical isolation" to "कार्यस्थल और विद्युत आइसोलेशन", "Core principles for safe work around electrical systems." to "विद्युत प्रणालियों के आसपास सुरक्षित कार्य के मूल सिद्धांत।", "Electrical fire & emergency response" to "विद्युत आग और आपातकालीन प्रतिक्रिया", "Protect people first during an incident." to "घटना के दौरान सबसे पहले लोगों की सुरक्षा करें।",
    "Check before use" to "उपयोग से पहले जाँचें", "Do not use cracked plugs, frayed cords, exposed wires or loose sockets." to "टूटे प्लग, घिसे तार, खुले चालक या ढीले सॉकेट का उपयोग न करें।", "Keep dry" to "सूखा रखें", "Keep hands dry and electrical appliances away from water." to "हाथ सूखे रखें और विद्युत उपकरणों को पानी से दूर रखें।", "Avoid overloading" to "अधिक भार से बचें", "Do not overload sockets or extension boards. Stay within rated capacity." to "सॉकेट या एक्सटेंशन बोर्ड पर अधिक भार न डालें। निर्धारित क्षमता के भीतर रहें।", "Switch off safely" to "सुरक्षित तरीके से बंद करें", "Unplug by holding the plug, not pulling the cord." to "तार खींचने के बजाय प्लग पकड़कर निकालें।",
    "Earthing" to "अर्थिंग", "Protective earthing provides a path for fault current and must be correctly installed." to "सुरक्षात्मक अर्थिंग दोष धारा के लिए मार्ग देती है और इसे सही ढंग से लगाना चाहिए।", "MCB" to "MCB", "An MCB protects wiring against overcurrent and short circuits; it does not alone provide all shock protection." to "MCB वायरिंग को अधिक धारा और शॉर्ट सर्किट से बचाता है; यह अकेले बिजली के झटके से पूरी सुरक्षा नहीं देता।", "RCCB/RCD" to "RCCB/RCD", "An RCCB/RCD detects certain leakage currents, but does not replace earthing or safe behaviour." to "RCCB/RCD कुछ रिसाव धाराओं का पता लगाता है, लेकिन अर्थिंग या सुरक्षित व्यवहार का विकल्प नहीं है।", "Never bypass" to "कभी बायपास न करें", "Never bypass a protective device or repeatedly reset one that trips." to "सुरक्षा उपकरण को कभी बायपास न करें और बार-बार ट्रिप होने पर उसे रीसेट न करते रहें।",
    "Warning signs" to "चेतावनी संकेत", "Burning smell, sparks, hot switches, buzzing or repeated tripping need prompt attention." to "जलने की गंध, चिंगारी, गर्म स्विच, भनभनाहट या बार-बार ट्रिप होने पर तुरंत ध्यान दें।", "Repairs" to "मरम्मत", "Do not carry out live electrical work. Use a qualified electrician." to "चालू बिजली पर काम न करें। योग्य इलेक्ट्रीशियन की सहायता लें।", "Children" to "बच्चे", "Keep cords out of reach and teach children never to insert objects into sockets." to "तार बच्चों की पहुँच से दूर रखें और उन्हें सॉकेट में वस्तु न डालना सिखाएँ।", "Temporary wiring" to "अस्थायी वायरिंग", "Avoid damaged extension leads, loose joints and cords under rugs." to "क्षतिग्रस्त एक्सटेंशन तार, ढीले जोड़ और कालीन के नीचे तार रखने से बचें।",
    "Keep distance" to "दूरी बनाए रखें", "Never approach or touch overhead electrical lines." to "ओवरहेड विद्युत लाइनों के पास न जाएँ और उन्हें न छुएँ।", "Fallen wires" to "गिरे हुए तार", "Assume a fallen conductor is live. Keep away and call the electricity utility/emergency services." to "गिरे तार को चालू मानें। दूर रहें और बिजली वितरण कंपनी/आपातकालीन सेवा को बुलाएँ।", "Ladders and kites" to "सीढ़ियाँ और पतंग", "Keep ladders, long objects and kites well clear of power lines." to "सीढ़ियों, लंबी वस्तुओं और पतंगों को बिजली की लाइनों से दूर रखें।", "Construction" to "निर्माण कार्य", "Never work near electrical infrastructure without authorised safety arrangements." to "अधिकृत सुरक्षा व्यवस्था के बिना विद्युत ढाँचे के पास काम न करें।",
    "Authorisation" to "अनुमति", "Only trained and authorised persons should perform electrical work." to "केवल प्रशिक्षित और अधिकृत व्यक्ति ही विद्युत कार्य करें।", "Isolation and LOTO" to "आइसोलेशन और LOTO", "Identify energy sources, isolate, lock and tag per site procedures, then verify absence of voltage." to "ऊर्जा स्रोत पहचानें, साइट प्रक्रिया के अनुसार अलग करें, लॉक और टैग लगाएँ, फिर वोल्टेज न होने की पुष्टि करें।", "PPE and tools" to "PPE और औज़ार", "Use inspected, task-appropriate PPE and insulated tools." to "जाँचे हुए, कार्यानुकूल PPE और इंसुलेटेड औज़ार इस्तेमाल करें।", "No assumptions" to "अनुमान न लगाएँ", "Never assume equipment is de-energised just because a switch is off." to "केवल स्विच बंद होने से यह न मानें कि उपकरण में बिजली नहीं है।",
    "Raise alarm" to "अलार्म दें", "Evacuate people, alert others and call emergency services." to "लोगों को बाहर निकालें, दूसरों को चेतावनी दें और आपातकालीन सेवा को बुलाएँ।", "Do not use water" to "पानी का उपयोग न करें", "Never apply water to equipment that may be energised." to "जिस उपकरण में बिजली हो सकती है, उस पर पानी न डालें।", "Shock response" to "झटके पर प्रतिक्रिया", "Do not touch a casualty until the source is safely isolated." to "स्रोत को सुरक्षित रूप से अलग करने तक पीड़ित को न छुएँ।", "Report hazards" to "खतरों की सूचना दें", "Report damaged equipment, near misses and incidents promptly." to "क्षतिग्रस्त उपकरण, लगभग हुई दुर्घटना और घटनाओं की तुरंत सूचना दें।",
    "Home safety check" to "घर की सुरक्षा जाँच", "If you find a defect, stop using the equipment and contact a qualified electrician." to "दोष मिलने पर उपकरण का उपयोग बंद करें और योग्य इलेक्ट्रीशियन से संपर्क करें।", "No frayed cords, cracked plugs or exposed wires" to "घिसे तार, टूटे प्लग या खुले तार नहीं हैं", "Sockets and extension boards are not overloaded" to "सॉकेट और एक्सटेंशन बोर्ड पर अधिक भार नहीं है", "No hot switches, sparks or burning smells" to "गर्म स्विच, चिंगारी या जलने की गंध नहीं है", "Electrical equipment is kept away from water" to "विद्युत उपकरण पानी से दूर रखे हैं", "Protective devices are not bypassed; repeated tripping is investigated" to "सुरक्षा उपकरण बायपास नहीं हैं; बार-बार ट्रिप होने की जाँच होती है",
    "Electrical emergency guide" to "विद्युत आपातकालीन मार्गदर्शिका", "Life-threatening emergency: keep away from the hazard. In India, call 112 for emergency assistance where appropriate." to "जानलेवा आपातस्थिति में खतरे से दूर रहें। भारत में आवश्यकतानुसार आपात सहायता के लिए 112 पर कॉल करें।", "⚡ Electric shock" to "⚡ बिजली का झटका", "🔥 Electrical fire" to "🔥 विद्युत आग", "⚠️ Fallen wire" to "⚠️ गिरा हुआ तार", "Do not touch the person while they may be in contact with a live source." to "जब तक व्यक्ति का चालू विद्युत स्रोत से संपर्क हो सकता है, उसे न छुएँ।", "Turn off supply only if safe to do so." to "केवल सुरक्षित होने पर बिजली की आपूर्ति बंद करें।", "Call emergency services. Once safe, follow dispatcher instructions for CPR/AED if trained." to "आपात सेवा को बुलाएँ। सुरक्षित होने पर, प्रशिक्षित हों तो CPR/AED के लिए निर्देशों का पालन करें।", "Raise the alarm, evacuate and call emergency services." to "चेतावनी दें, बाहर निकलें और आपात सेवा को बुलाएँ।", "Never throw water on equipment that may be live." to "जिस उपकरण में बिजली हो सकती है उस पर पानी कभी न डालें।", "Use an extinguisher only if trained, suitable and you have a clear escape route." to "अग्निशामक का उपयोग तभी करें जब प्रशिक्षित हों, वह उपयुक्त हो और निकलने का रास्ता खुला हो।", "Treat every fallen wire as live. Keep well away and warn others." to "हर गिरे तार को चालू मानें। दूर रहें और दूसरों को चेतावनी दें।", "Do not touch the wire, nearby objects or anyone in contact with it." to "तार, पास की वस्तुओं या उससे संपर्क में व्यक्ति को न छुएँ।", "Contact the electricity utility and emergency services." to "बिजली वितरण कंपनी और आपात सेवा से संपर्क करें।", "General awareness only; follow local emergency procedures and formal training." to "यह सामान्य जानकारी है; स्थानीय आपात प्रक्रियाओं और औपचारिक प्रशिक्षण का पालन करें।",
    "Your progress" to "आपकी प्रगति", "Learning summary" to "सीखने का सारांश", "Progress is saved on this device." to "प्रगति इस डिवाइस पर सहेजी जाती है।", "← All lessons" to "← सभी पाठ", "Mark lesson explored ✓" to "पाठ पूरा चिह्नित करें ✓", "Lesson reviewed ✓" to "पाठ दोहराया गया ✓", "Quick quiz" to "त्वरित प्रश्नोत्तरी", "Quiz complete!" to "प्रश्नोत्तरी पूरी हुई!", "Answer review" to "उत्तर समीक्षा", "Try again" to "फिर प्रयास करें", "Finish quiz" to "प्रश्नोत्तरी समाप्त करें", "Next question →" to "अगला प्रश्न →", "Correct:" to "सही उत्तर:", "Your score:" to "आपका स्कोर:", "English" to "अंग्रेज़ी", "Hindi" to "हिन्दी", "Change app language" to "ऐप की भाषा बदलें", "Choose the language for the entire app. Your progress will be preserved." to "पूरे ऐप की भाषा चुनें। आपकी प्रगति सुरक्षित रहेगी।", "Language changed to Hindi" to "ऐप की भाषा हिन्दी कर दी गई है", "भाषा बदलकर English कर दी गई है" to "Language changed to English",
    "You notice a frayed power cord. What should you do?" to "आपको बिजली का घिसा हुआ तार दिखता है। क्या करना चाहिए?", "Wrap it in paper" to "इसे कागज़ से लपेट दें", "Stop using it and arrange safe replacement" to "उपयोग बंद करें और सुरक्षित रूप से बदलवाएँ", "Keep using it if it works" to "चल रहा है तो उपयोग करते रहें", "Damaged cords can expose live conductors and cause shock or fire." to "क्षतिग्रस्त तार में चालू चालक खुल सकते हैं और झटका या आग लग सकती है।",
    "An RCCB/RCD trips repeatedly. What is safest?" to "RCCB/RCD बार-बार ट्रिप होता है। सबसे सुरक्षित कदम क्या है?", "Bypass it" to "इसे बायपास करें", "Fit a larger fuse without checking" to "जाँच किए बिना बड़ा फ्यूज़ लगाएँ", "Stop resetting it and ask a qualified electrician" to "रीसेट करना बंद करें और योग्य इलेक्ट्रीशियन से संपर्क करें", "Repeated tripping can indicate a fault. Never bypass protection." to "बार-बार ट्रिप होना दोष का संकेत हो सकता है। सुरक्षा को कभी बायपास न करें।",
    "A person may be receiving an electric shock. What should you do first?" to "किसी व्यक्ति को बिजली का झटका लग रहा हो सकता है। पहले क्या करें?", "Grab their hand" to "उसका हाथ पकड़ें", "Avoid touching them; isolate power only if safe and call for help" to "उसे न छुएँ; केवल सुरक्षित होने पर बिजली अलग करें और मदद बुलाएँ", "Pour water nearby" to "पास में पानी डालें", "You could become a second casualty if the source is live." to "स्रोत चालू होने पर आप भी पीड़ित हो सकते हैं।",
    "You see a fallen overhead wire. What should you do?" to "आपको ओवरहेड तार गिरा हुआ दिखता है। क्या करें?", "Move it with a stick" to "डंडे से हटाएँ", "Keep away and report it as live" to "दूर रहें और उसे चालू मानकर सूचना दें", "Walk over it carefully" to "सावधानी से उसके ऊपर से चलें", "Fallen wires can remain energised." to "गिरे तारों में बिजली हो सकती है।",
    "What is an MCB primarily designed to protect against?" to "MCB मुख्य रूप से किससे सुरक्षा के लिए बनाया गया है?", "All electric shocks" to "सभी बिजली के झटकों से", "Overcurrent and short circuits" to "अधिक धारा और शॉर्ट सर्किट से", "Every electrical fire" to "हर विद्युत आग से", "An MCB does not replace an RCD or earthing." to "MCB, RCD या अर्थिंग का विकल्प नहीं है।",
    "Before electrical maintenance, what is essential?" to "विद्युत रखरखाव से पहले क्या आवश्यक है?", "Assume the switch is enough" to "मान लें कि स्विच बंद करना पर्याप्त है", "Follow isolation/lockout procedures and verify absence of voltage" to "आइसोलेशन/लॉकआउट प्रक्रिया अपनाएँ और वोल्टेज न होने की पुष्टि करें", "Wear rubber-soled shoes only" to "केवल रबर के तलवे वाले जूते पहनें", "Safe work requires controlled isolation and verification." to "सुरक्षित कार्य के लिए नियंत्रित आइसोलेशन और पुष्टि आवश्यक है।",
    "Electrical safety learning" to "विद्युत सुरक्षा शिक्षा", "Question" to "प्रश्न", "Correct:" to "सही उत्तर:", "Answer review" to "उत्तर समीक्षा", "English interface" to "अंग्रेज़ी इंटरफ़ेस"
)

private fun translateText(text: String): String {
    if (!appHindi) return text
    hindiText[text]?.let { return it }
    return when {
        text.startsWith("Question ") && text.contains(" of ") -> text.replace("Question ", "प्रश्न ").replace(" of ", " में से ")
        text.matches(Regex("\\d+ of 5 completed")) -> text.replace(" of ", " में से ").replace(" completed", " पूरे")
        text.matches(Regex("\\d+ of 6 lessons explored")) -> text.replace(" of ", " में से ").replace(" lessons explored", " पाठ पूरे")
        text.endsWith(" quiz points") -> text.removeSuffix(" quiz points") + " प्रश्नोत्तरी अंक"
        text.startsWith("Correct: ") -> "सही उत्तर: " + text.removePrefix("Correct: ")
        else -> text
    }
}

@Composable
private fun Text(
    text: String, modifier: Modifier = Modifier, color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified, fontWeight: FontWeight? = null,
    textAlign: TextAlign? = null, maxLines: Int = Int.MAX_VALUE
) {
    MaterialText(text = translateText(text), modifier = modifier, color = color, fontSize = fontSize,
        fontWeight = fontWeight, textAlign = textAlign, maxLines = maxLines)
}

private val Navy = Color(0xFF0B1F33)
private val Blue = Color(0xFF155EEF)
private val Pale = Color(0xFFF3F6FB)
private val Teal = Color(0xFF0D9488)

data class Lesson(val icon: String, val title: String, val summary: String, val points: List<Pair<String,String>>)
private val lessons = listOf(
    Lesson("🔌","Plugs, sockets & appliances","Use electricity without overloading or damaging equipment.", listOf(
        "Check before use" to "Do not use cracked plugs, frayed cords, exposed wires or loose sockets.",
        "Keep dry" to "Keep hands dry and electrical appliances away from water.",
        "Avoid overloading" to "Do not overload sockets or extension boards. Stay within rated capacity.",
        "Switch off safely" to "Unplug by holding the plug, not pulling the cord."
    )),
    Lesson("🛡️","Earthing & protective devices","Understand earthing, MCBs and RCCBs/RCDs.", listOf(
        "Earthing" to "Protective earthing provides a path for fault current and must be correctly installed.",
        "MCB" to "An MCB protects wiring against overcurrent and short circuits; it does not alone provide all shock protection.",
        "RCCB/RCD" to "An RCCB/RCD detects certain leakage currents, but does not replace earthing or safe behaviour.",
        "Never bypass" to "Never bypass a protective device or repeatedly reset one that trips."
    )),
    Lesson("🏠","Safe wiring at home","Recognise warning signs and arrange safe repairs.", listOf(
        "Warning signs" to "Burning smell, sparks, hot switches, buzzing or repeated tripping need prompt attention.",
        "Repairs" to "Do not carry out live electrical work. Use a qualified electrician.",
        "Children" to "Keep cords out of reach and teach children never to insert objects into sockets.",
        "Temporary wiring" to "Avoid damaged extension leads, loose joints and cords under rugs."
    )),
    Lesson("⚡","Overhead lines & outdoor safety","Stay away from overhead lines and fallen conductors.", listOf(
        "Keep distance" to "Never approach or touch overhead electrical lines.",
        "Fallen wires" to "Assume a fallen conductor is live. Keep away and call the electricity utility/emergency services.",
        "Ladders and kites" to "Keep ladders, long objects and kites well clear of power lines.",
        "Construction" to "Never work near electrical infrastructure without authorised safety arrangements."
    )),
    Lesson("🏢","Workplace & electrical isolation","Core principles for safe work around electrical systems.", listOf(
        "Authorisation" to "Only trained and authorised persons should perform electrical work.",
        "Isolation and LOTO" to "Identify energy sources, isolate, lock and tag per site procedures, then verify absence of voltage.",
        "PPE and tools" to "Use inspected, task-appropriate PPE and insulated tools.",
        "No assumptions" to "Never assume equipment is de-energised just because a switch is off."
    )),
    Lesson("🔥","Electrical fire & emergency response","Protect people first during an incident.", listOf(
        "Raise alarm" to "Evacuate people, alert others and call emergency services.",
        "Do not use water" to "Never apply water to equipment that may be energised.",
        "Shock response" to "Do not touch a casualty until the source is safely isolated.",
        "Report hazards" to "Report damaged equipment, near misses and incidents promptly."
    ))
)
data class Question(val prompt: String, val options: List<String>, val answer: Int, val explanation: String)
private val questions = listOf(
    Question("You notice a frayed power cord. What should you do?", listOf("Wrap it in paper","Stop using it and arrange safe replacement","Keep using it if it works"),1,"Damaged cords can expose live conductors and cause shock or fire."),
    Question("An RCCB/RCD trips repeatedly. What is safest?",listOf("Bypass it","Fit a larger fuse without checking","Stop resetting it and ask a qualified electrician"),2,"Repeated tripping can indicate a fault. Never bypass protection."),
    Question("A person may be receiving an electric shock. What should you do first?",listOf("Grab their hand","Avoid touching them; isolate power only if safe and call for help","Pour water nearby"),1,"You could become a second casualty if the source is live."),
    Question("You see a fallen overhead wire. What should you do?",listOf("Move it with a stick","Keep away and report it as live","Walk over it carefully"),1,"Fallen wires can remain energised."),
    Question("What is an MCB primarily designed to protect against?",listOf("All electric shocks","Overcurrent and short circuits","Every electrical fire"),1,"An MCB does not replace an RCD or earthing."),
    Question("Before electrical maintenance, what is essential?",listOf("Assume the switch is enough","Follow isolation/lockout procedures and verify absence of voltage","Wear rubber-soled shoes only"),1,"Safe work requires controlled isolation and verification.")
)
private val checkItems = listOf(
    "No frayed cords, cracked plugs or exposed wires",
    "Sockets and extension boards are not overloaded",
    "No hot switches, sparks or burning smells",
    "Electrical equipment is kept away from water",
    "Protective devices are not bypassed; repeated tripping is investigated"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VidyutApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VidyutApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("vs_progress", 0) }
    LaunchedEffect(Unit) { appHindi = prefs.getBoolean("hindi_language", false) }
    val completed = remember { mutableStateListOf<Int>().apply { addAll(prefs.getStringSet("lessons", emptySet())!!.mapNotNull { it.toIntOrNull() }) } }
    val checked = remember { mutableStateListOf<Int>().apply { addAll(prefs.getStringSet("checks", emptySet())!!.mapNotNull { it.toIntOrNull() }) } }
    var score by remember { mutableIntStateOf(prefs.getInt("score",0)) }
    var tab by remember { mutableStateOf("Home") }
    var lessonIndex by remember { mutableIntStateOf(-1) }
    var quizIndex by remember { mutableIntStateOf(-1) }
    var qIndex by remember { mutableIntStateOf(0) }
    var selected by remember { mutableIntStateOf(-1) }
    var quizScore by remember { mutableIntStateOf(0) }
    var quizDone by remember { mutableStateOf(false) }
    fun persist() {
        prefs.edit().putStringSet("lessons", completed.map { it.toString() }.toSet())
            .putStringSet("checks", checked.map { it.toString() }.toSet()).putInt("score", score).apply()
    }
    MaterialTheme(colorScheme = lightColorScheme(primary=Blue, secondary=Teal, background=Pale)) {
        Scaffold(
            containerColor = Pale,
            topBar = {
                if (lessonIndex < 0 && quizIndex < 0) TopAppBar(
                    title = { Column { Text("⚡ Vidyut Suraksha", fontWeight=FontWeight.Bold, color=Color.White); Text("Electrical safety learning", fontSize=12.sp, color=Color(0xFFD5E5F5)) } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor=Navy)
                )
            },
            bottomBar = {
                NavigationBar(containerColor=Color.White) {
                    listOf("Home","Learn","Quiz","Check","Progress","Language","Safety Regulations").forEach { name ->
                        NavigationBarItem(selected=tab==name, onClick={
                            tab=name; lessonIndex=-1; quizIndex=-1; quizDone=false
                        }, icon={
                            when(name) {
                                "Home" -> Icon(Icons.Default.Home, null)
                                "Learn" -> Icon(Icons.Default.MenuBook, null)
                                "Quiz" -> Icon(Icons.Default.Quiz, null)
                                "Check" -> Icon(Icons.Default.CheckCircle, null)
                                "Language" -> Icon(Icons.Default.Translate, null)
                                "Safety Regulations" -> Icon(Icons.Default.Gavel, null)
                                else -> Icon(Icons.Default.Insights, null)
                            }
                        }, label={ Text(name) })
                    }
                }
            }
        ) { padding ->
            if (lessonIndex >= 0) LessonScreen(lessons[lessonIndex], completed.contains(lessonIndex), Modifier.padding(padding), onBack={lessonIndex=-1;tab="Learn"}, onComplete={
                if (!completed.contains(lessonIndex)) completed.add(lessonIndex)
                persist()
            })
            else if (quizIndex >= 0) QuizScreen(qIndex, selected, quizDone, quizScore, Modifier.padding(padding),
                onSelect={ selected=it },
                onNext={
                    if (selected == questions[qIndex].answer) quizScore++
                    if (qIndex < questions.lastIndex) { qIndex++; selected=-1 }
                    else { score += quizScore; persist(); quizDone=true }
                },
                onRetry={ qIndex=0;selected=-1;quizScore=0;quizDone=false })
            else when(tab) {
                "Home" -> HomeScreen(completed.size, score, checked.size, Modifier.padding(padding),
                    onLearn={tab="Learn"}, onQuiz={tab="Quiz";quizIndex=0;qIndex=0;selected=-1;quizScore=0;quizDone=false},
                    onCheck={tab="Check"}, onEmergency={tab="Emergency"})
                "Learn" -> LessonsScreen(completed, Modifier.padding(padding), onOpen={lessonIndex=it})
                "Quiz" -> { LaunchedEffect(tab) { if (quizIndex < 0) { quizIndex=0;qIndex=0;selected=-1;quizScore=0;quizDone=false } }; Box(Modifier.padding(padding)) { } }
                "Check" -> ChecklistScreen(checked, Modifier.padding(padding), onToggle={i,on -> if(on && !checked.contains(i))checked.add(i) else if(!on)checked.remove(i);persist()})
                "Progress" -> ProgressScreen(completed.size, score, checked.size, Modifier.padding(padding))
                "Language" -> LanguageScreen(Modifier.padding(padding), onToggle = { appHindi = it; prefs.edit().putBoolean("hindi_language", it).apply() })
                "Safety Regulations" -> SafetyRegulationsScreen(Modifier.padding(padding))
                "Emergency" -> EmergencyScreen(Modifier.padding(padding))
                else -> HomeScreen(completed.size,score,checked.size,Modifier.padding(padding),{tab="Learn"},{tab="Quiz";quizIndex=0},{tab="Check"},{tab="Emergency"})
            }
        }
    }
}

@Composable
fun LanguageScreen(modifier: Modifier, onToggle: (Boolean) -> Unit) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Change app language", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Choose the language for the entire app. Your progress will be preserved.", color = Color.Gray)
        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("English", fontWeight = FontWeight.Bold); Text("English interface", color = Color.Gray, fontSize = 13.sp) }
                    RadioButton(selected = !appHindi, onClick = { onToggle(false) })
                }
                Divider()
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("Hindi", fontWeight = FontWeight.Bold); Text("हिन्दी इंटरफ़ेस", color = Color.Gray, fontSize = 13.sp) }
                    RadioButton(selected = appHindi, onClick = { onToggle(true) })
                }
            }
        }
        Text(if (appHindi) "Language changed to Hindi" else "भाषा बदलकर English कर दी गई है", color = Teal, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun HomeScreen(done:Int, score:Int, checks:Int, modifier:Modifier, onLearn:()->Unit, onQuiz:()->Unit, onCheck:()->Unit, onEmergency:()->Unit) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {
            Card(colors=CardDefaults.cardColors(containerColor=Navy), shape=MaterialTheme.shapes.extraLarge) {
                Column(Modifier.padding(20.dp)) {
                    Text("LEARN SAFE. STAY SAFE.", color=Color(0xFFFBBF24), fontSize=12.sp, fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(8.dp)); Text("Electrical safety starts with you.", color=Color.White, fontSize=25.sp, fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(8.dp)); Text("Short lessons, practical checks and quick quizzes.", color=Color(0xFFD5E5F5))
                    Spacer(Modifier.height(18.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                        Stat("$done/6","Lessons"); Stat("$score","Quiz points"); Stat("$checks/5","Checks")
                    }
                }
            }
        }
        item { Text("Start learning", fontSize=20.sp, fontWeight=FontWeight.Bold) }
        item { FeatureCard("📘","Safety lessons","Six bite-sized topics",onLearn) }
        item { FeatureCard("🧠","Quick quiz","Test your knowledge",onQuiz) }
        item { FeatureCard("✅","Home safety check","Check common household hazards",onCheck) }
        item { FeatureCard("🚨","Emergency guide","Shock, fire and fallen wires",onEmergency) }
        item { SafetyNotice("Never touch a person who may still be in contact with electricity. Isolate power only if safe, keep away and call emergency services.") }
    }
}
@Composable fun Stat(value:String,label:String) { Column { Text(value,color=Color.White,fontWeight=FontWeight.Bold,fontSize=20.sp);Text(label,color=Color(0xFFD5E5F5),fontSize=11.sp) } }
@Composable fun FeatureCard(emoji:String,title:String,desc:String,onClick:()->Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick=onClick), colors=CardDefaults.cardColors(containerColor=Color.White), elevation=CardDefaults.cardElevation(1.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
            Text(emoji,fontSize=28.sp); Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) { Text(title,fontWeight=FontWeight.Bold,fontSize=16.sp); Text(desc,color=Color.Gray,fontSize=13.sp) }
            Icon(Icons.Default.ChevronRight,null,tint=Blue)
        }
    }
}
@Composable
private fun LessonIllustration(icon: String, index: Int, compact: Boolean) {
    val backgrounds = listOf(Color(0xFFE0F2FE), Color(0xFFDCFCE7), Color(0xFFFFEDD5), Color(0xFFFEF3C7), Color(0xFFEDE9FE), Color(0xFFFEE2E2))
    val accents = listOf(Color(0xFF0284C7), Color(0xFF059669), Color(0xFFEA580C), Color(0xFFCA8A04), Color(0xFF7C3AED), Color(0xFFDC2626))
    Box(
        Modifier
            .then(if (compact) Modifier.size(76.dp, 68.dp) else Modifier.fillMaxWidth().height(170.dp))
            .background(backgrounds[index.coerceIn(0, 5)], MaterialTheme.shapes.large),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(icon, fontSize = if (compact) 30.sp else 66.sp)
            if (!compact) {
                Spacer(Modifier.height(6.dp))
                Text(listOf("PLUG SAFELY", "PROTECT & EARTH", "SAFE HOME WIRING", "KEEP YOUR DISTANCE", "ISOLATE & VERIFY", "RESPOND SAFELY")[index.coerceIn(0, 5)], color=accents[index.coerceIn(0, 5)], fontSize=12.sp, fontWeight=FontWeight.ExtraBold)
            }
        }
    }
}

@Composable
fun SafetyRegulationsScreen(modifier: Modifier) {
    val uriHandler = LocalUriHandler.current
    val officialUrl = "https://cea.nic.in/regulations/central-electricity-authority-measures-relating-to-safety-and-electric-supply-regulations-2023/?lang=en"
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Text("Safety Regulations", fontSize=24.sp, fontWeight=FontWeight.Bold)
        Card(colors=CardDefaults.cardColors(containerColor=Color.White)) {
            Column(Modifier.padding(18.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                Text("Central Electricity Authority (Measures relating to Safety and Electric Supply) Regulations, 2023", fontSize=18.sp, fontWeight=FontWeight.Bold)
                Text("Official Central Electricity Authority website", color=Color.Gray, fontSize=14.sp)
                Text("Open the official CEA regulations page to view the notified 2023 regulations and its PDF.", fontSize=14.sp)
                Button(onClick={ uriHandler.openUri(officialUrl) }, modifier=Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.OpenInNew, contentDescription=null)
                    Spacer(Modifier.width(8.dp))
                    Text("Open CEA Safety Regulations, 2023")
                }
                Text("Regulations open in your browser.", color=Color.Gray, fontSize=12.sp)
            }
        }
    }
}

@Composable fun SafetyNotice(text:String) {
    Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFFFF4D6))) { Row(Modifier.padding(14.dp)) { Icon(Icons.Default.Warning,null,tint=Color(0xFF9A6700)); Spacer(Modifier.width(8.dp)); Text(text,color=Color(0xFF7A4B00),fontSize=13.sp) } }
}
@Composable fun LessonsScreen(completed:List<Int>, modifier:Modifier, onOpen:(Int)->Unit) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item { Text("Learning modules",fontSize=23.sp,fontWeight=FontWeight.Bold); Text("Choose a topic to study.",color=Color.Gray) }
        itemsIndexed(lessons) { i,l ->
            Card(Modifier.fillMaxWidth().clickable { onOpen(i) }, colors=CardDefaults.cardColors(containerColor=Color.White)) {
                Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically) {
                    LessonIllustration(icon=l.icon, index=i, compact=true); Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Text(l.title,fontWeight=FontWeight.Bold);Text(l.summary,fontSize=13.sp,color=Color.Gray) }
                    if(completed.contains(i)) Icon(Icons.Default.CheckCircle,null,tint=Teal) else Icon(Icons.Default.ChevronRight,null)
                }
            }
        }
    }
}
@Composable fun LessonScreen(lesson:Lesson, isDone:Boolean, modifier:Modifier, onBack:()->Unit, onComplete:()->Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("← All lessons",color=Blue,fontWeight=FontWeight.Bold,modifier=Modifier.clickable(onClick=onBack))
        Spacer(Modifier.height(16.dp)); LessonIllustration(icon=lesson.icon, index=lessons.indexOf(lesson), compact=false); Spacer(Modifier.height(14.dp)); Text(lesson.title,fontSize=25.sp,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(8.dp));Text(lesson.summary,color=Color.Gray)
        lesson.points.forEachIndexed { i,p ->
            Card(Modifier.fillMaxWidth().padding(top=10.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
                Column(Modifier.padding(16.dp)) { Text("${i+1}. ${p.first}",fontWeight=FontWeight.Bold);Spacer(Modifier.height(5.dp));Text(p.second) }
            }
        }
        Spacer(Modifier.height(18.dp));Button(onClick=onComplete,modifier=Modifier.fillMaxWidth()) { Text(if(isDone)"Lesson reviewed ✓" else "Mark lesson explored ✓") }
    }
}
@Composable fun QuizScreen(index:Int, selected:Int, done:Boolean, finalScore:Int, modifier:Modifier, onSelect:(Int)->Unit, onNext:()->Unit, onRetry:()->Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        if(done) {
            Text("🏆",fontSize=42.sp);Text("Quiz complete!",fontSize=25.sp,fontWeight=FontWeight.Bold)
            Text("Your score: $finalScore / ${questions.size}",fontSize=18.sp)
            Spacer(Modifier.height(12.dp));Button(onClick=onRetry,modifier=Modifier.fillMaxWidth()){Text("Try again")}
            Text("Answer review",fontWeight=FontWeight.Bold,fontSize=20.sp,modifier=Modifier.padding(top=18.dp))
            questions.forEachIndexed { i,q -> Card(Modifier.fillMaxWidth().padding(top=8.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) { Column(Modifier.padding(14.dp)){Text("${i+1}. ${q.prompt}",fontWeight=FontWeight.Bold);Text("Correct: ${q.options[q.answer]}");Text(q.explanation,color=Color.Gray,fontSize=13.sp)} } }
        } else {
            Text("Quick quiz",fontSize=24.sp,fontWeight=FontWeight.Bold);Text("Question ${index+1} of ${questions.size}",color=Color.Gray)
            LinearProgressIndicator(progress={ (index+1).toFloat()/questions.size },modifier=Modifier.fillMaxWidth().padding(vertical=12.dp))
            Text(questions[index].prompt,fontSize=19.sp,fontWeight=FontWeight.Bold)
            questions[index].options.forEachIndexed { i,option ->
                Card(Modifier.fillMaxWidth().padding(top=10.dp).clickable { onSelect(i) },colors=CardDefaults.cardColors(containerColor=if(selected==i)Color(0xFFEAF2FF) else Color.White)) {
                    Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically) { RadioButton(selected==i,onClick={onSelect(i)});Spacer(Modifier.width(8.dp));Text(option) }
                }
            }
            Spacer(Modifier.height(18.dp));Button(onClick=onNext,enabled=selected>=0,modifier=Modifier.fillMaxWidth()){Text(if(index==questions.lastIndex)"Finish quiz" else "Next question →")}
        }
    }
}
@Composable fun ChecklistScreen(checked:List<Int>, modifier:Modifier, onToggle:(Int,Boolean)->Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Home safety check",fontSize=24.sp,fontWeight=FontWeight.Bold);Text("If you find a defect, stop using the equipment and contact a qualified electrician.",color=Color.Gray)
        Spacer(Modifier.height(10.dp))
        checkItems.forEachIndexed { i,item ->
            Card(Modifier.fillMaxWidth().padding(vertical=5.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
                Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically) { Checkbox(checked.contains(i),onCheckedChange={onToggle(i,it)});Spacer(Modifier.width(8.dp));Text(item) }
            }
        }
        Spacer(Modifier.height(12.dp));LinearProgressIndicator(progress={checked.size/5f},modifier=Modifier.fillMaxWidth());Text("${checked.size} of 5 completed",color=Color.Gray)
    }
}
@Composable fun EmergencyScreen(modifier:Modifier) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Electrical emergency guide",fontSize=24.sp,fontWeight=FontWeight.Bold)
        SafetyNotice("Life-threatening emergency: keep away from the hazard. In India, call 112 for emergency assistance where appropriate.")
        EmergencyCard("⚡ Electric shock",listOf("Do not touch the person while they may be in contact with a live source.","Turn off supply only if safe to do so.","Call emergency services. Once safe, follow dispatcher instructions for CPR/AED if trained."))
        EmergencyCard("🔥 Electrical fire",listOf("Raise the alarm, evacuate and call emergency services.","Never throw water on equipment that may be live.","Use an extinguisher only if trained, suitable and you have a clear escape route."))
        EmergencyCard("⚠️ Fallen wire",listOf("Treat every fallen wire as live. Keep well away and warn others.","Do not touch the wire, nearby objects or anyone in contact with it.","Contact the electricity utility and emergency services."))
        Text("General awareness only; follow local emergency procedures and formal training.",color=Color.Gray,fontSize=12.sp,modifier=Modifier.padding(top=12.dp))
    }
}
@Composable fun EmergencyCard(title:String,points:List<String>) {
    Card(Modifier.fillMaxWidth().padding(vertical=6.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
        Column(Modifier.padding(15.dp)) { Text(title,fontWeight=FontWeight.Bold,fontSize=17.sp);points.forEach { Text("• $it",modifier=Modifier.padding(top=7.dp),fontSize=14.sp) } }
    }
}
@Composable fun ProgressScreen(done:Int, score:Int, checks:Int, modifier:Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Your progress",fontSize=24.sp,fontWeight=FontWeight.Bold)
        Card(Modifier.fillMaxWidth().padding(top=12.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
            Column(Modifier.padding(18.dp)) {
                Text("Learning summary",fontWeight=FontWeight.Bold,fontSize=18.sp)
                Text("$done of 6 lessons explored",modifier=Modifier.padding(top=12.dp))
                LinearProgressIndicator(progress={done/6f},modifier=Modifier.fillMaxWidth().padding(vertical=6.dp))
                Text("$score quiz points",modifier=Modifier.padding(top=8.dp))
                Text("$checks of 5 home safety checks completed",modifier=Modifier.padding(top=8.dp))
                LinearProgressIndicator(progress={checks/5f},modifier=Modifier.fillMaxWidth().padding(vertical=6.dp))
                Text("Progress is saved on this device.",color=Color.Gray,fontSize=12.sp,modifier=Modifier.padding(top=8.dp))
            }
        }
    }
}
