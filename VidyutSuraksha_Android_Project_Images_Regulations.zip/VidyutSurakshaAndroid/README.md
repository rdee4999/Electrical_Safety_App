# Vidyut Suraksha — Native Android MVP

This is a **native Android project** using Kotlin and Jetpack Compose, not a web app.

## Features
- 6 electrical safety learning modules
- 6-question quiz with score and answer explanations
- Home electrical safety checklist
- Emergency awareness guide for electric shock, electrical fires and fallen wires
- Local progress persistence with Android SharedPreferences
- Bottom navigation and mobile-first Material 3 interface

## Build an APK
### Option A: Android Studio
1. Open this project folder in Android Studio (recent version).
2. Allow Gradle sync and install any requested Android SDK components.
3. Select **Build > Build APK(s)**.
4. Debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

### Option B: Build from a phone using GitHub Actions
This repository includes `.github/workflows/build-apk.yml`.
1. Create a GitHub account and a new repository.
2. Upload all files/folders in this project to the repository.
3. Open the **Actions** tab and enable workflows if prompted.
4. Run **Build Android APK** (or push a commit to the main branch).
5. Open the completed workflow run and download the `VidyutSuraksha-debug-apk` artifact.
6. Extract the downloaded artifact ZIP to get `app-debug.apk`, then install it on your Android phone. Android may ask you to allow installs from that source.

## Notes
- This source project is not itself an APK. It must be compiled by Android Studio or GitHub Actions.
- The workflow builds a debug APK for testing; it is not a Play Store release-signed build.
- Educational content is general awareness only. Verify technical/legal content against current CEA regulations, applicable Indian standards and authorised site procedures before professional use.
